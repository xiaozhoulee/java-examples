package com.alipay.demo.trade.model.result;

public interface Result {
    boolean isTradeSuccess();
}
