package com.kk.pay.base.service;

public interface Validator {
    String getField();

    boolean isRequired();
}
