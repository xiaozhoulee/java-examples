 package com.alipay.demo.trade.model;
 
 public enum TradeStatus
 {
   SUCCESS, 
 
   FAILED, 
 
   UNKNOWN;
 }
