package com.alipay.demo.trade.model.hb;

public enum Type {
    CR,

    STORE,

    VM,

    MD,

    SOFT_POS,

    POS,

    ALI_POS;
}
