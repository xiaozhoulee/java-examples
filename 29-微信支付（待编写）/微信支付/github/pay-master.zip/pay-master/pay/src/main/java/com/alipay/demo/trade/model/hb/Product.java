package com.alipay.demo.trade.model.hb;

public enum Product {
    FP,

    MP;
}
