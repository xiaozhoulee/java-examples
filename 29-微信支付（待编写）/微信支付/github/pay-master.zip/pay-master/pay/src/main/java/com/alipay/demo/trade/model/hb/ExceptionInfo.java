 package com.alipay.demo.trade.model.hb;
 
 public enum ExceptionInfo
 {
   HE_PRINTER, 
 
   HE_SCANER, 
 
   HE_OTHER;
 }
