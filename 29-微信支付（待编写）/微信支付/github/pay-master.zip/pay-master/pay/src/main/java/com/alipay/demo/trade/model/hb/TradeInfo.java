package com.alipay.demo.trade.model.hb;

public interface TradeInfo {
    HbStatus getStatus();

    double getTimeConsume();
}
