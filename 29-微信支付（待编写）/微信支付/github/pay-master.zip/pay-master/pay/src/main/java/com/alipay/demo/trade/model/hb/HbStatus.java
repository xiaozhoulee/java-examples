package com.alipay.demo.trade.model.hb;

public enum HbStatus {
    S,

    I,

    F,

    P,

    X,

    Y,

    Z,

    C,

    T;
}
