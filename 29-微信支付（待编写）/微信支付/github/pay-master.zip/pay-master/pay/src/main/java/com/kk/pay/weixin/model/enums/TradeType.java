package com.kk.pay.weixin.model.enums;

public enum TradeType {
    JSAPI, NATIVE, APP, WAP;
}
