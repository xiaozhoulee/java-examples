package com.kk.util;

public class Consts {
    public static final String domain = "http://sandbox.kk.com";
    public static final String domain_caller = "http://www.kk.com";

    public static final String notifyUrlWeixin = "http://www.kk.com/caller/notify/weixin";

    public static final String mchId = "0001";
    public static final String apiKey = "ak";

    public static final String openId = "";
}
