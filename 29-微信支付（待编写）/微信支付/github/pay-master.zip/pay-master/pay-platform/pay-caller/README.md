# cashier.jsp
用户扫码微信支付，